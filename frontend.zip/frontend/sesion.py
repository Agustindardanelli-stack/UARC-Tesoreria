class Session:
    def __init__(self, token=None):
        self.token = token

    def set_token(self, token):
        self.token = token

    def get_headers(self):
        if self.token:
            return {"Authorization": f"Bearer {self.token}"}
        return {}

    def logout(self):
        self.token = None

# Instancia global
session = Session()
