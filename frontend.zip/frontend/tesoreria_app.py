import sys
import os
import requests
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QPushButton, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtCore import Qt

# Agregar la ruta del proyecto al PATH
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Importaciones desde la carpeta 'views'
from views.dashboard import Dashboard
from views.cobranzas import Cobranzas
from views.pagos import Pagos
from views.reportes import Reportes
from views.login import LoginWindow  
from views.socio_couta import CuotasSocietarias
import sesion  # Módulo para manejar la sesión del usuario


class TesoreriaApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gestión de Tesorería")
        self.setGeometry(100, 100, 1000, 600)
        self.initUI()

    def initUI(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QHBoxLayout()
        central_widget.setLayout(layout)

        # 📌 MENÚ LATERAL
        self.menu_widget = QWidget()
        menu_layout = QVBoxLayout()
        self.menu_widget.setLayout(menu_layout)

        # Botones del menú
        self.btn_dashboard = QPushButton("Dashboard")
        self.btn_pagos = QPushButton("Pagos")
        self.btn_cobranzas = QPushButton("Cobranzas")
        self.btn_reportes = QPushButton("Reportes")
        self.btn_cuotas = QPushButton("Cuotas Societarias")  # 📌 Nuevo botón
        self.btn_logout = QPushButton("Cerrar Sesión")

        # Conectar botones a funciones
        self.btn_dashboard.clicked.connect(self.mostrar_dashboard)
        self.btn_pagos.clicked.connect(self.mostrar_pagos)
        self.btn_cobranzas.clicked.connect(self.mostrar_cobranzas)
        self.btn_reportes.clicked.connect(self.mostrar_reportes)
        self.btn_cuotas.clicked.connect(self.mostrar_cuotas_societarias)  # 📌 Conectar nuevo botón
        self.btn_logout.clicked.connect(self.logout)

        # Agregar botones al menú lateral
        menu_layout.addWidget(self.btn_dashboard)
        menu_layout.addWidget(self.btn_pagos)
        menu_layout.addWidget(self.btn_cobranzas)
        menu_layout.addWidget(self.btn_reportes)
        menu_layout.addWidget(self.btn_cuotas)  # 📌 Agregar botón al menú
        menu_layout.addStretch()
        menu_layout.addWidget(self.btn_logout)  # Botón de logout

        layout.addWidget(self.menu_widget)

        # Contenido dinámico
        self.content_widget = QWidget()
        layout.addWidget(self.content_widget)

        self.mostrar_dashboard()  # Mostrar dashboard al inicio

    def set_nueva_vista(self, nueva_vista):
        """Reemplaza el contenido principal por la nueva vista."""
        layout = self.centralWidget().layout()
        layout.replaceWidget(self.content_widget, nueva_vista)
        self.content_widget.deleteLater()
        self.content_widget = nueva_vista

    # 📌 Métodos para cambiar de vista
    def mostrar_dashboard(self):
        print("📌 Intentando mostrar el Dashboard...")
        try:
            self.set_nueva_vista(Dashboard(sesion.session.token))  # ✅ Pasar el token
        except Exception as e:
            print(f"❌ Error al cargar Dashboard: {e}")

    def mostrar_pagos(self):
        print("📌 Intentando mostrar Pagos...")
        try:
            self.set_nueva_vista(Pagos(sesion.session.token))  # ✅ Pasar el token
        except Exception as e:
            print(f"❌ Error al cargar Pagos: {e}")

    def mostrar_cobranzas(self):
        print("📌 Intentando mostrar Cobranzas...")
        try:
            self.set_nueva_vista(Cobranzas(sesion.session.token))  # ✅ Pasar el token
        except Exception as e:
            print(f"❌ Error al cargar Cobranzas: {e}")

    def mostrar_reportes(self):
        print("📌 Intentando mostrar Reportes...")
        try:
            self.set_nueva_vista(Reportes(sesion.session.token))  # ✅ Pasar el token
        except Exception as e:
            print(f"❌ Error al cargar Reportes: {e}")

    def mostrar_cuotas_societarias(self):
        print("📌 Intentando mostrar Cuotas Societarias...")
        try:
            self.set_nueva_vista(CuotasSocietarias(sesion.session.token))  # ✅ Pasar el token
        except Exception as e:
            print(f"❌ Error al cargar Cuotas Societarias: {e}")

    def logout(self):
        """Cerrar sesión y volver al login"""
        confirm = QMessageBox.question(
            self, "Cerrar Sesión", "¿Seguro que quieres cerrar sesión?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if confirm == QMessageBox.Yes:
            sesion.session.logout()
            QMessageBox.information(self, "Sesión Cerrada", "Has cerrado sesión exitosamente.")
            self.close()
            main()


def main():
    """Función principal para ejecutar la app con login"""
    app = QApplication(sys.argv)
    login_window = LoginWindow()

    if login_window.exec_() == 1:  # Si el login es exitoso
        window = TesoreriaApp()
        window.show()
        sys.exit(app.exec_())


if __name__ == "__main__":
    main()
