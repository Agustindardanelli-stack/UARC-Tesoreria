import requests
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QMessageBox

class Importes(QWidget):
    def __init__(self, token):
        super().__init__()
        self.token = token
        self.setWindowTitle("Gestión de Importes")
        self.setGeometry(200, 200, 600, 400)

        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Categoría", "Importe", "Retención"])
        layout.addWidget(self.table)

        self.btn_cargar = QPushButton("Cargar Importes")
        self.btn_cargar.clicked.connect(self.load_importes)
        layout.addWidget(self.btn_cargar)

        self.setLayout(layout)
        self.load_importes()

    def load_importes(self):
        url = f"{BASE_URL}/importes"
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            importes = response.json()
            self.table.setRowCount(len(importes))
            for row, importe in enumerate(importes):
                self.table.setItem(row, 0, QTableWidgetItem(importe["categoria"]))
                self.table.setItem(row, 1, QTableWidgetItem(f"${importe["importe"]:.2f}"))
                self.table.setItem(row, 2, QTableWidgetItem(f"${importe["retencion"]:.2f}"))
        else:
            QMessageBox.critical(self, "Error", "No se pudieron cargar los importes")