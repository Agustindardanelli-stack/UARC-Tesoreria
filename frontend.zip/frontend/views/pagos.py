import requests
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, 
    QLabel, QMessageBox, QLineEdit, QFormLayout, QComboBox,QCalendarWidget
)
from functools import partial

BASE_URL = "http://127.0.0.1:8000"

class Pagos(QWidget):
    def __init__(self, token):
        super().__init__()
        self.token = token
        self.setWindowTitle("Gestión de Pagos")
        self.setGeometry(200, 200, 600, 500)

        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Fecha", "Usuario", "monto", "Retención", "Acciones"])
        layout.addWidget(self.table)

        form_layout = QFormLayout()
        self.fecha_input = QCalendarWidget()
        self.fecha_input.setGridVisible(True)  # Muestra la cuadrícula del calendario
        self.fecha_input.setMaximumHeight(200)  # Ajusta el tamaño del widget
        self.usuario_input = QComboBox()
        self.monto_input = QLineEdit()
        self.retencion_input = QComboBox()
        form_layout.addRow("Fecha:", self.fecha_input)
        form_layout.addRow("Usuario:", self.usuario_input)
        form_layout.addRow("monto:", self.monto_input)
        form_layout.addRow("Retención:", self.retencion_input)
        layout.addLayout(form_layout)

        self.btn_agregar = QPushButton("Agregar Pago")
        self.btn_agregar.clicked.connect(self.agregar_pago)
        layout.addWidget(self.btn_agregar)

        self.btn_cargar = QPushButton("Cargar Pagos")
        self.btn_cargar.clicked.connect(self.load_pagos)
        layout.addWidget(self.btn_cargar)

        self.setLayout(layout)
        self.load_usuarios()
        self.load_retenciones()
        self.load_pagos()

    def load_usuarios(self):
        url = f"{BASE_URL}/usuarios"
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            usuarios = response.json()
            self.usuario_input.clear()
            for usuario in usuarios:
                self.usuario_input.addItem(usuario["nombre"], usuario["id"])
        else:
            QMessageBox.critical(self, "Error", f"No se pudieron cargar los usuarios.\n{response.text}")

    def load_retenciones(self):
        url = f"{BASE_URL}/retenciones"
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            retenciones = response.json()
            self.retencion_input.clear()
            for retencion in retenciones:
                self.retencion_input.addItem(retencion["nombre"], retencion["id"])
        else:
            QMessageBox.critical(self, "Error", f"No se pudieron cargar las retenciones.\n{response.text}")

    def agregar_pago(self):
        url = f"{BASE_URL}/pagos"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }

        fecha_qdate = self.fecha_input.selectedDate()  # Obtiene la fecha seleccionada
        fecha = fecha_qdate.toString("yyyy-MM-dd")  # Convierte al formato requerido

        usuario_id = self.usuario_input.currentData()
        monto_texto = self.monto_input.text().strip()
        retencion_id = self.retencion_input.currentData()

        if not fecha or not usuario_id:
            QMessageBox.critical(self, "Error", "Debe completar todos los campos obligatorios.")
            return

        try:
            monto = float(monto_texto)
            if monto <= 0:
                raise ValueError("El monto debe ser mayor a 0.")
        except ValueError:
            QMessageBox.critical(self, "Error", "El monto debe ser un número válido mayor a 0.")
            return

        data = {
            "fecha": fecha,
            "usuario_id": usuario_id,
            "monto": monto,
            "retencion_id": retencion_id if retencion_id else None
        }

        response = requests.post(url, json=data, headers=headers)

        if response.status_code == 201:
            QMessageBox.information(self, "Éxito", "Pago agregado correctamente.")
            self.load_pagos()
        else:
            QMessageBox.critical(self, "Error", f"No se pudo agregar el pago.\n{response.text}")

    def load_pagos(self):
        url = f"{BASE_URL}/pagos"
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            pagos = response.json()
            self.table.setRowCount(0)  # Limpiar la tabla antes de cargar nuevos datos

            for row, pago in enumerate(pagos):
                self.table.insertRow(row)
                self.table.setItem(row, 0, QTableWidgetItem(pago.get("fecha", "N/A")))
                self.table.setItem(row, 1, QTableWidgetItem(pago.get("usuario", "Desconocido")))
                self.table.setItem(row, 2, QTableWidgetItem(f"${pago.get('monto', 0):.2f}"))

                retencion_nombre = pago.get("retencion", "N/A")
                self.table.setItem(row, 3, QTableWidgetItem(retencion_nombre if retencion_nombre else "N/A"))

                btn_eliminar = QPushButton("Eliminar")
                btn_eliminar.clicked.connect(partial(self.eliminar_pago, pago["id"]))
                self.table.setCellWidget(row, 4, btn_eliminar)
        else:
            QMessageBox.critical(self, "Error", f"No se pudieron cargar los pagos.\n{response.text}")

    def eliminar_pago(self, pago_id):
        print(f"Intentando eliminar pago con ID: {pago_id}")  
        url = f"{BASE_URL}/pagos/{pago_id}"
        headers = {"Authorization": f"Bearer {self.token}"}

        confirm = QMessageBox.question(
            self, "Confirmar", "¿Estás seguro de que deseas eliminar este pago?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )

        if confirm == QMessageBox.Yes:
            response = requests.delete(url, headers=headers)

            if response.status_code == 200:
                QMessageBox.information(self, "Éxito", "Pago eliminado correctamente.")
                self.load_pagos()
            else:
                QMessageBox.critical(self, "Error", f"No se pudo eliminar el pago.\n{response.text}")
