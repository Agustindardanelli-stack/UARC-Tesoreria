import requests
from PyQt5.QtWidgets import (
    QMainWindow, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
    QLabel, QLineEdit, QPushButton, QHBoxLayout, QMessageBox
)
from PyQt5.QtCore import Qt

BASE_URL = "http://127.0.0.1:8000"

class Dashboard(QMainWindow):
    def __init__(self, token):
        super().__init__()
        self.token = token

        self.setWindowTitle("Dashboard - Tesorería")
        self.setGeometry(150, 150, 800, 500)
        self.setStyleSheet("background-color: #2C3E50; color: #ECF0F1; font-size: 14px;")

        layout = QVBoxLayout()
        
        # Etiquetas de ingresos y egresos
        self.label_ingresos = QLabel("INGRESOS: $0.00")
        self.label_egresos = QLabel("EGRESOS: $0.00")
        self.label_ingresos.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.label_egresos.setStyleSheet("font-size: 16px; font-weight: bold;")

        header_layout = QHBoxLayout()
        header_layout.addWidget(self.label_ingresos)
        header_layout.addWidget(self.label_egresos)
        layout.addLayout(header_layout)
        
        # Tabla de partidas
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["Fecha", "Detalle", "Ingreso", "Egreso", "Saldo"])
        self.table.setStyleSheet("background-color: #ECF0F1; color: #2C3E50; font-size: 13px;")
        layout.addWidget(self.table)
        
        # Botón para actualizar datos
        self.btn_actualizar = QPushButton("Actualizar")
        self.btn_actualizar.setStyleSheet("background-color: #27AE60; color: white; padding: 8px;")
        self.btn_actualizar.clicked.connect(self.load_data)
        layout.addWidget(self.btn_actualizar)
        
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)
        
        self.load_data()

    def load_data(self):
        url = f"{BASE_URL}/partidas"
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            partidas = response.json()
            self.table.setRowCount(len(partidas))
            total_ingresos = 0
            total_egresos = 0
            
            for row, partida in enumerate(partidas):
                ingreso = float(partida.get("ingreso", 0))
                egreso = float(partida.get("egreso", 0))
                saldo = ingreso - egreso

                total_ingresos += ingreso
                total_egresos += egreso

                self.table.setItem(row, 0, QTableWidgetItem(partida["fecha"]))
                self.table.setItem(row, 1, QTableWidgetItem(partida["detalle"]))
                self.table.setItem(row, 2, QTableWidgetItem(f"${ingreso:.2f}"))
                self.table.setItem(row, 3, QTableWidgetItem(f"${egreso:.2f}"))
                self.table.setItem(row, 4, QTableWidgetItem(f"${saldo:.2f}"))
            
            self.label_ingresos.setText(f"INGRESOS: ${total_ingresos:.2f}")
            self.label_egresos.setText(f"EGRESOS: ${total_egresos:.2f}")
        else:
            QMessageBox.critical(self, "Error", f"No se pudieron obtener los datos. Código: {response.status_code}")
