from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QCheckBox
)
from PyQt5.QtGui import QFont, QPalette, QColor, QPixmap 
from PyQt5.QtCore import Qt
import requests

import sesion

class LoginWindow(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Iniciar Sesión")
        self.setGeometry(100, 100, 400, 250)
        self.setStyleSheet(self.get_styles())  # Aplicar estilos
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)

        self.label_logo = QLabel(self)
        pixmap = QPixmap('assets/UarcLogo.jpg')  # Asegúrate de que la ruta sea correcta
        self.label_logo.setPixmap(pixmap)
        self.label_logo.setScaledContents(True)  # Escalar la imagen si es necesario
        self.label_logo.setFixedSize(100, 100)  # Ajusta el tamaño del logo
        self.resize(pixmap.width(), pixmap.height())

        self.setStyleSheet("background-color: #2c3e50; color: #ecf0f1;")

        lbl_title = QLabel("Gestión de Tesorería")
        lbl_title.setFont(QFont("Arial", 16, QFont.Bold))
        lbl_title.setAlignment(Qt.AlignCenter)

        self.txt_email = QLineEdit()
        self.txt_email.setPlaceholderText("Correo electrónico")

        self.txt_password = QLineEdit()
        self.txt_password.setPlaceholderText("Contraseña")
        self.txt_password.setEchoMode(QLineEdit.Password)

        self.chk_show_password = QCheckBox("Mostrar contraseña")
        self.chk_show_password.stateChanged.connect(self.toggle_password)

        self.btn_login = QPushButton("Ingresar")
        self.btn_login.clicked.connect(self.check_login)  

        layout.addWidget(lbl_title)
        layout.addWidget(self.txt_email)
        layout.addWidget(self.txt_password)
        layout.addWidget(self.chk_show_password)
        layout.addWidget(self.btn_login)

        self.setLayout(layout)

    def toggle_password(self, state):
        """Muestra u oculta la contraseña"""
        if state == Qt.Checked:
            self.txt_password.setEchoMode(QLineEdit.Normal)
        else:
            self.txt_password.setEchoMode(QLineEdit.Password)

    def check_login(self):
        """Valida el usuario y contraseña con el backend"""
        url = "http://localhost:8000/login"
        input_email = self.txt_email.text().strip()
        input_password = self.txt_password.text().strip()

        if not input_email or not input_password:
            QMessageBox.warning(self, "Error", "Por favor, completa todos los campos.")
            return

        data = {
            "username": input_email,  # OAuth2 usa 'username' en lugar de 'email'
            "password": input_password
        }

        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(url, data=data, headers=headers)
            
            if response.status_code == 200:
                token = response.json().get("access_token")
                if token:
                    sesion.session.set_token(token)  # ✅ Guardar el token globalmente
                    print(f"✅ Token guardado en sesión: {sesion.session.token}")  # <-- Debug
                    QMessageBox.information(self, "Éxito", "Inicio de sesión exitoso.")
                    self.accept()
                else:
                    QMessageBox.warning(self, "Error", "No se recibió el token.")
            else:
                error_msg = response.json().get("detail", "Usuario o contraseña incorrectos.")
                QMessageBox.warning(self, "Error", error_msg)
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, "Error", f"No se pudo conectar con el servidor.\n{str(e)}")


        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            response = requests.post(url, data=data, headers=headers)
            
            if response.status_code == 200:
                token = response.json().get("access_token")
                if token:
                    self.token = token
                    QMessageBox.information(self, "Éxito", "Inicio de sesión exitoso.")
                    self.accept()  # ✅ Cierra el diálogo y devuelve 1
                else:
                    QMessageBox.warning(self, "Error", "No se recibió el token.")
            else:
                error_msg = response.json().get("detail", "Usuario o contraseña incorrectos.")
                QMessageBox.warning(self, "Error", error_msg)
        except requests.exceptions.RequestException as e:
            QMessageBox.critical(self, "Error", f"No se pudo conectar con el servidor.\n{str(e)}")

    def get_token(self):
        """Devuelve el token almacenado."""
        return self.token

    def get_styles(self):
        """Estilos personalizados con QSS"""
        return """
            QWidget {
                background-color: #f4f4f4;
            }
            QLabel {
                color: #333;
                font-size: 14px;
            }
            QLineEdit {
                border: 2px solid #ccc;
                border-radius: 8px;
                padding: 8px;
                font-size: 14px;
            }
            QPushButton {
                background-color: #0078D7;
                color: white;
                border-radius: 8px;
                padding: 10px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """

