import requests
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QFileDialog, QMessageBox
import pandas as pd

class Reportes(QWidget):
    def __init__(self, token):
        super().__init__()
        self.token = token
        self.setWindowTitle("Generación de Reportes")
        self.setGeometry(200, 200, 400, 300)

        layout = QVBoxLayout()

        self.btn_generar_excel = QPushButton("Exportar a Excel")
        self.btn_generar_excel.clicked.connect(self.exportar_excel)
        layout.addWidget(self.btn_generar_excel)

        self.btn_generar_pdf = QPushButton("Exportar a PDF")
        self.btn_generar_pdf.clicked.connect(self.exportar_pdf)
        layout.addWidget(self.btn_generar_pdf)

        self.setLayout(layout)
    
    def exportar_excel(self):
        data = self.obtener_datos()
        if data:
            df = pd.DataFrame(data)
            file_path, _ = QFileDialog.getSaveFileName(self, "Guardar Reporte", "reporte.xlsx", "Excel Files (*.xlsx)")
            if file_path:
                df.to_excel(file_path, index=False)
                QMessageBox.information(self, "Éxito", "Reporte exportado correctamente")

    def exportar_pdf(self):
        QMessageBox.information(self, "Info", "Funcionalidad en desarrollo")
    
    def obtener_datos(self):
        url = f"{BASE_URL}/reportes"
        headers = {"Authorization": f"Bearer {self.token}"}
        response = requests.get(url, headers=headers)
        return response.json() if response.status_code == 200 else None