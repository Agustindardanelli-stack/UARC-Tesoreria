import sys
import requests
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QTableWidget, QTableWidgetItem, QMessageBox

API_URL = "http://127.0.0.1:8000/cuotas"


class CuotasSocietarias(QWidget):
    def __init__(self, token=None):
        super().__init__()

        self.token = token

        self.setWindowTitle("Cuotas Societarias")
        self.setGeometry(100, 100, 600, 600)

        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        self.tabla = QTableWidget()
        self.layout.addWidget(self.tabla)

        self.btn_actualizar = QPushButton("Actualizar Lista")
        self.btn_actualizar.clicked.connect(self.cargar_cuotas)
        self.layout.addWidget(self.btn_actualizar)

        self.cargar_cuotas()

    def cargar_cuotas(self):
        """Obtiene la lista de cuotas desde la API y la muestra en la tabla."""
        try:
            headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
            response = requests.get(API_URL, headers=headers)

            if response.status_code != 200:
                QMessageBox.warning(self, "Error", f"Error en la API: {response.status_code}")
                return

            cuotas = response.json()

            if not isinstance(cuotas, list):  # Verifica que sea una lista
                QMessageBox.critical(self, "Error", "La API devolvió una respuesta no válida.")
                return

            self.tabla.setRowCount(len(cuotas))
            self.tabla.setColumnCount(5)  # Columnas: Usuario, Fecha, Monto, Estado, Acción
            self.tabla.setHorizontalHeaderLabels(["Usuario", "Fecha", "Monto", "Estado", "Acción"])

            for fila, cuota in enumerate(cuotas):
                # 🔹 Obtener el nombre del usuario (evita KeyError si falta la clave)
                usuario_nombre = cuota.get("usuario", {}).get("nombre", "N/A")

                self.tabla.setItem(fila, 0, QTableWidgetItem(usuario_nombre))  # Nombre del usuario
                self.tabla.setItem(fila, 1, QTableWidgetItem(cuota.get("fecha", "N/A")))  # Fecha
                self.tabla.setItem(fila, 2, QTableWidgetItem(f"${cuota.get('monto', 0):,.2f}"))  # Monto

                estado = "✅ Pagado" if cuota.get("pagado", False) else "❌ No Pagado"
                self.tabla.setItem(fila, 3, QTableWidgetItem(estado))  # Estado de pago

                # Botón para pagar solo si no está pagado
                if not cuota.get("pagado", False):
                    btn_pagar = QPushButton("Marcar Pago")
                    btn_pagar.clicked.connect(lambda _, id=cuota["id"]: self.marcar_pago(id))
                    self.tabla.setCellWidget(fila, 4, btn_pagar)

        except requests.RequestException as e:
            QMessageBox.critical(self, "Error", f"No se pudo conectar con la API:\n{e}")

    def marcar_pago(self, cuota_id):
        """Envía la solicitud para marcar como pagada una cuota."""
        try:
            headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
            response = requests.post(f"{API_URL}/pagar/{cuota_id}", headers=headers)

            if response.status_code == 200:
                QMessageBox.information(self, "Pago realizado", "La cuota ha sido marcada como pagada.")
                self.cargar_cuotas()  # Refrescar la tabla
            else:
                QMessageBox.warning(self, "Error", f"No se pudo procesar el pago. Código: {response.status_code}")

        except requests.RequestException as e:
            QMessageBox.critical(self, "Error", f"No se pudo conectar con la API:\n{e}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = CuotasSocietarias(token="tu_token_aqui")  # Pasa el token si es necesario
    ventana.show()
    sys.exit(app.exec_())
