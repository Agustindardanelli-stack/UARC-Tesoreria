import sys
import requests
import pandas as pd
from PyQt5.QtWidgets import (
    QMainWindow, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget,
    QTableWidgetItem, QWidget, QLabel, QDateEdit, QLineEdit, QComboBox, 
    QDialog, QFormLayout, QMessageBox, QApplication
)
from PyQt5.QtCore import QDate
from PyQt5.QtPrintSupport import QPrintDialog, QPrinter

# Configuración de la API
API_BASE_URL = "http://localhost:8000"  # URL base de tu API
API_PARTIDAS_URL = f"{API_BASE_URL}/partidas/"
API_USUARIOS_URL = f"{API_BASE_URL}/usuarios/"

class Cobranzas(QDialog):
    def __init__(self, usuarios, parent=None):
        super().__init__(parent)
        self.usuarios = usuarios
        self.setWindowTitle("Registrar Partida")
        self.setGeometry(200, 200, 400, 350)
        
        layout = QFormLayout()
        
        # Fecha (pre-seleccionada con la fecha actual)
        self.fecha_edit = QDateEdit()
        self.fecha_edit.setCalendarPopup(True)
        self.fecha_edit.setDate(QDate.currentDate())
        layout.addRow("Fecha:", self.fecha_edit)
        
        # Detalle
        self.detalle_input = QLineEdit()
        layout.addRow("Detalle:", self.detalle_input)
        
        # Tipo de Partida
        self.tipo_combo = QComboBox()
        self.tipo_combo.addItems(["Ingreso", "Egreso"])
        layout.addRow("Tipo:", self.tipo_combo)
        
        # Monto
        self.monto_input = QLineEdit()
        layout.addRow("Monto:", self.monto_input)
        
        # Selección de Usuario (opcional)
        self.usuario_combo = QComboBox()
        self.usuario_combo.addItem("Sin Usuario", userData=None)
        for usuario in usuarios:
            self.usuario_combo.addItem(f"{usuario['nombre']} (ID: {usuario['id']})", userData=usuario['id'])
        layout.addRow("Usuario:", self.usuario_combo)
        
        # Botones
        btn_layout = QHBoxLayout()
        guardar_btn = QPushButton("Guardar")
        guardar_btn.clicked.connect(self.accept)
        cancelar_btn = QPushButton("Cancelar")
        cancelar_btn.clicked.connect(self.reject)
        
        btn_layout.addWidget(guardar_btn)
        btn_layout.addWidget(cancelar_btn)
        layout.addRow(btn_layout)
        
        self.setLayout(layout)
    
    def get_data(self):
        # Preparar datos según el tipo de partida
        monto = float(self.monto_input.text())
        tipo = self.tipo_combo.currentText()
        
        payload = {
            "fecha": self.fecha_edit.date().toString("yyyy-MM-dd"),
            "detalle": self.detalle_input.text(),
            "ingreso": monto if tipo == "Ingreso" else 0,
            "egreso": monto if tipo == "Egreso" else 0,
            "usuario_id": self.usuario_combo.currentData()
        }
        
        return payload

class Partidas(QMainWindow):
    def __init__(self, token=None):
        super().__init__()
        self.token = token
        self.setWindowTitle("Libro Diario - Gestión Financiera")
        self.setGeometry(100, 100, 1200, 700)
        
        # Cargar usuarios al inicializar
        self.usuarios = self.cargar_usuarios()
        
        self.initUI()
        self.loadData()
    
    def cargar_usuarios(self):
        """Cargar lista de usuarios desde la API"""
        try:
            headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
            response = requests.get(API_USUARIOS_URL, headers=headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                QMessageBox.warning(self, "Error", f"No se pudieron cargar los usuarios: {response.text}")
                return []
        except requests.RequestException as e:
            QMessageBox.critical(self, "Error de Conexión", f"No se pudo conectar con la API: {str(e)}")
            return []
    
    def initUI(self):
        container = QWidget()
        layout = QVBoxLayout()
        
        # Filtro de fecha
        fecha_layout = QHBoxLayout()
        self.date_label = QLabel("Filtrar por fecha:")
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.dateChanged.connect(self.loadData)
        
        fecha_layout.addWidget(self.date_label)
        fecha_layout.addWidget(self.date_edit)
        
        # Botones de acción
        btn_layout = QHBoxLayout()
        self.nueva_partida_btn = QPushButton("Nueva Partida")
        self.nueva_partida_btn.clicked.connect(self.agregar_partida)
        
        self.export_btn = QPushButton("Exportar a Excel")
        self.export_btn.clicked.connect(self.exportToExcel)
        
        btn_layout.addWidget(self.nueva_partida_btn)
        btn_layout.addWidget(self.export_btn)
        
        # Tabla de partidas
        self.table = QTableWidget()
        self.table.setColumnCount(7)  # ID, Fecha, Detalle, Ingreso, Egreso, Saldo, Usuario
        self.table.setHorizontalHeaderLabels([
            "ID", "Fecha", "Detalle", "Ingreso", "Egreso", "Saldo", "Usuario"
        ])
        
        # Agregar elementos al layout principal
        layout.addLayout(fecha_layout)
        layout.addLayout(btn_layout)
        layout.addWidget(self.table)
        
        # Totales
        totales_layout = QHBoxLayout()
        self.total_ingresos_label = QLabel("Total Ingresos: $0.00")
        self.total_egresos_label = QLabel("Total Egresos: $0.00")
        totales_layout.addWidget(self.total_ingresos_label)
        totales_layout.addWidget(self.total_egresos_label)
        layout.addLayout(totales_layout)
        
        container.setLayout(layout)
        self.setCentralWidget(container)
    
    def agregar_partida(self):
        dialog = PartidaEntradaDialog(self.usuarios, self)
        if dialog.exec_() == QDialog.Accepted:
            datos = dialog.get_data()
            
            try:
                # Enviar los datos a la API
                headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
                response = requests.post(API_PARTIDAS_URL, json=datos, headers=headers)
                
                if response.status_code == 201:  # Creación exitosa
                    partida = response.json()
                    
                    # Agregar a la tabla
                    row_count = self.table.rowCount()
                    self.table.insertRow(row_count)
                    
                    self.table.setItem(row_count, 0, QTableWidgetItem(str(partida['id'])))
                    self.table.setItem(row_count, 1, QTableWidgetItem(partida['fecha']))
                    self.table.setItem(row_count, 2, QTableWidgetItem(partida['detalle']))
                    self.table.setItem(row_count, 3, QTableWidgetItem(f"${partida['ingreso']:.2f}"))
                    self.table.setItem(row_count, 4, QTableWidgetItem(f"${partida['egreso']:.2f}"))
                    self.table.setItem(row_count, 5, QTableWidgetItem(f"${partida['saldo']:.2f}"))
                    
                    # Mostrar nombre de usuario si existe
                    usuario_nombre = 'Sin Usuario'
                    if partida.get('usuario'):
                        usuario_nombre = partida['usuario'].get('nombre', 'Sin Nombre')
                    self.table.setItem(row_count, 6, QTableWidgetItem(usuario_nombre))
                    
                    QMessageBox.information(self, "Éxito", "Partida agregada correctamente")
                    
                    # Recargar datos para actualizar totales
                    self.loadData()
                else:
                    QMessageBox.warning(self, "Error", f"No se pudo agregar la partida: {response.text}")
            
            except requests.RequestException as e:
                QMessageBox.critical(self, "Error de Conexión", f"No se pudo conectar con la API: {str(e)}")
    
    def loadData(self):
        # Convertir fecha del filtro
        selected_date = self.date_edit.date().toString("yyyy-MM-dd")
        
        try:
            # Usar endpoint de filtro por fecha
            url = f"{API_PARTIDAS_URL}?fecha={selected_date}"
            headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                partidas = response.json()
                
                # Limpiar tabla actual
                self.table.setRowCount(0)
                
                # Variables para totales
                total_ingresos = 0
                total_egresos = 0
                
                # Llenar tabla con datos de la API
                for partida in partidas:
                    row_count = self.table.rowCount()
                    self.table.insertRow(row_count)
                    
                    self.table.setItem(row_count, 0, QTableWidgetItem(str(partida['id'])))
                    self.table.setItem(row_count, 1, QTableWidgetItem(partida['fecha']))
                    self.table.setItem(row_count, 2, QTableWidgetItem(partida['detalle']))
                    self.table.setItem(row_count, 3, QTableWidgetItem(f"${partida['ingreso']:.2f}"))
                    self.table.setItem(row_count, 4, QTableWidgetItem(f"${partida['egreso']:.2f}"))
                    self.table.setItem(row_count, 5, QTableWidgetItem(f"${partida['saldo']:.2f}"))
                    
                    # Mostrar nombre de usuario si existe
                    usuario_nombre = 'Sin Usuario'
                    if partida.get('usuario'):
                        usuario_nombre = partida['usuario'].get('nombre', 'Sin Nombre')
                    self.table.setItem(row_count, 6, QTableWidgetItem(usuario_nombre))
                    
                    # Calcular totales
                    total_ingresos += float(partida['ingreso'])
                    total_egresos += float(partida['egreso'])
                
                # Actualizar etiquetas de totales
                self.total_ingresos_label.setText(f"Total Ingresos: ${total_ingresos:.2f}")
                self.total_egresos_label.setText(f"Total Egresos: ${total_egresos:.2f}")
            else:
                QMessageBox.warning(self, "Error", f"No se pudieron cargar las partidas: {response.text}")
        
        except requests.RequestException as e:
            QMessageBox.critical(self, "Error de Conexión", f"No se pudo conectar con la API: {str(e)}")
    
    def exportToExcel(self):
        rows = []
        for row in range(self.table.rowCount()):
            row_data = [self.table.item(row, col).text() for col in range(self.table.columnCount())]
            rows.append(row_data)
        
        df = pd.DataFrame(rows, columns=[
            "ID", "Fecha", "Detalle", "Ingreso", "Egreso", "Saldo", "Usuario"
        ])
        df.to_excel("partidas.xlsx", index=False)
        QMessageBox.information(self, "Exportar", "Partidas exportadas a partidas.xlsx")

